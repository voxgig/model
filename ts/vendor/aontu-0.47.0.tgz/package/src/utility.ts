/* Copyright (c) 2023-2025 Richard Rodger, MIT License */



import type { Val } from './type'


// Default walk() depth limit. High enough that real configs are never
// silently truncated (the old default of 32 dropped marks on deeply
// nested refs/funcs → wrong output), while still bounding runaway or
// accidentally-cyclic walks (walk has no cycle detection). Pass null for
// truly unbounded.
const WALK_DEFAULT_MAXDEPTH = 9999


// Mark value in source is propagated to target (true ratchets).
function propagateMarks(source: Val, target: Val): void {
  // Don't infect top!
  if (source.isTop || target.isTop) {
    return
  }
  for (let name in source.mark) {
    (target.mark as any)[name] = (target.mark as any)[name] || (source.mark as any)[name]
  }
}


function formatPath(path: Val | string[], absolute?: boolean) {
  let parts: string[]
  if (Array.isArray(path)) {
    parts = path
  }
  else {
    parts = path.path
  }

  let pathstr = (0 < parts.length && false !== absolute ? '$.' : '') + parts.join('.')

  return pathstr
}


type WalkApply = (
  key: string | number | undefined,
  val: Val,
  parent: Val | undefined,
  path: (string | number)[]
) => Val

/**
 * Walk a Val structure depth first, applying functions before and after descending.
 * Only traverses Val instances - stops at non-Val children.
 */
function walk(
  // These arguments are the public interface.
  val: Val,

  // Before descending into a node.
  before?: WalkApply,

  // After descending into a node.
  after?: WalkApply,

  // Maximum recursive depth, default: WALK_DEFAULT_MAXDEPTH. Use null for
  // infinite depth.
  maxdepth?: number | null,

  // These arguments are used for recursive state.
  key?: string | number,
  parent?: Val,
  path?: (string | number)[]
): Val {
  let out = null == before ? val : before(key, val, parent, path || [])

  maxdepth = null != maxdepth && 0 <= maxdepth ? maxdepth : WALK_DEFAULT_MAXDEPTH
  if (null != maxdepth && 0 === maxdepth) {
    return out
  }
  if (null != path && null != maxdepth && 0 < maxdepth && maxdepth <= path.length) {
    return out
  }

  const child: any = out.peg

  // Container Vals (Map etc) have peg = plain {} or []
  if (null != child && !child.isVal) {
    if ('object' === typeof child) {
      for (let ckey in child) {
        if (child[ckey] && child[ckey].isVal) {
          child[ckey] = walk(
            child[ckey], before, after, maxdepth, ckey, out, [...(path || []), ckey])
        }
      }
    }
    else if (Array.isArray(child)) {
      for (let i = 0; i < child.length; i++) {
        if (child[i] && child[i].isVal) {
          child[i] = walk(
            child[i], before, after, maxdepth, i, out, [...(path || []), '' + i])
        }
      }
    }
  }

  out = null == after ? out : after(key, out, parent, path || [])

  return out
}


const T_NOTE = 0
const T_WHY = 1
const T_PATH = 2
const T_AVAL = 3
const T_BVAL = 4
const T_OVAL = 5
const T_CHILDREN = 6


function explainOpen(
  ctx: any,
  t: any[] | undefined | null | false,
  note: string,
  ac?: Val,
  bc?: Val
): any[] | null {
  if (false === t) return null;

  t = t ?? [null, 'root', null, null, null, null]
  t[T_WHY] = t[T_WHY] ?? ''
  t[T_NOTE] = (0 <= ctx.cc ? ctx.cc + '~' : '') + note
  t[T_PATH] = ['$', ctx.path.join('.')].filter(p => '' != p).join('.') + '  '
  if (ac) {
    t[T_AVAL] = ac.id + (ac.done ? '' : '!') + '=' + ac.canon
  }
  if (bc) {
    t[T_BVAL] = bc.id + (bc.done ? '' : '!') + '=' + bc.canon
  }

  return t
}


function ec(t: any[] | undefined | null, why: string) {
  if (null == t) return;

  const child = [null, why, null, null, null, null]
  t[T_CHILDREN] = t[T_CHILDREN] ?? []
  t[T_CHILDREN].push(child)
  return child
}


function explainClose(t: any[] | undefined | null, out?: Val) {
  if (null == t) return;

  if (out) {
    t[T_OVAL] = '-> ' + out.id + (out.done ? '' : '!') + '=' + out.canon
  }
}


function formatExplain(t: any[], d?: number) {
  d = null == d ? 0 : d
  const indent = ('  '.repeat(d))

  if (Array.isArray(t)) {
    const b = [
      indent + t.slice(0, t.length - 1).join(' ')
    ]

    const children = t[t.length - 1]
    if (Array.isArray(children)) {
      for (let ce of children) {
        b.push(formatExplain(ce, d + 1))
      }
    }

    return b.join('\n')
  }
  else {
    return indent + t
  }
}


function items(o: any) {
  if (Array.isArray(o)) {
    return o.map((n: any, i: number) => ([i, n]))
  }
  else if (null != o && 'object' === typeof o) {
    return Object.entries(o)
  }
  else {
    return []
  }
}


export {
  items,
  propagateMarks,
  formatPath,
  walk,
  WalkApply,
  explainOpen,
  ec,
  explainClose,
  formatExplain,
}

