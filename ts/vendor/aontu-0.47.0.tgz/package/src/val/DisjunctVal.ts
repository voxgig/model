/* Copyright (c) 2021-2025 Richard Rodger, MIT License */



import type {
  Val,
  ValSpec,
} from '../type'

import {
  DONE,
} from '../type'

import { AontuContext } from '../ctx'

import { makeNilErr } from '../err'
import { unite } from '../unify'

import {
  explainOpen,
  ec,
  explainClose,
} from '../utility'

import {
  Site
} from '../site'

import {
  top
} from './top'

import { NilVal, TRIAL_NIL } from '../val/NilVal'
import { PrefVal } from '../val/PrefVal'
import { JunctionVal } from '../val/JunctionVal'



// TODO: move main logic to op/disjunct
class DisjunctVal extends JunctionVal {
  isDisjunct = true
  isGenable = true
  cjo = 35000

  prefsRanked = false

  // TODO: sites from normalization of orginal Disjuncts, as well as child pegs
  constructor(
    spec: {
      peg: Val[]
    },
    ctx?: AontuContext,
    _sites?: Site[]
  ) {
    super(spec, ctx)
  }


  // NOTE: mutation!
  append(peer: Val): DisjunctVal {
    super.append(peer)
    this.prefsRanked = false
    return this
  }


  unify(peer: Val, ctx: AontuContext): Val {
    peer = peer ?? top()

    const te = ctx.explain && explainOpen(ctx, ctx.explain, 'Disjunct', this, peer)

    if (!this.prefsRanked) {
      this.rankPrefs(ctx)
    }

    // // // console.log('DISJUNCT-unify-A', this.id, this.canon)

    let done = true

    let oval: Val[] = []

    // Conjunction (&) distributes over disjunction (|).
    //
    // Each member is tried against peer in isolation: if that trial
    // produces any errors, the member fails and is marked with a NilVal.
    // Previously this used `ctx?.clone({err: []})` per member - a
    // per-iteration context clone (two Object.creates) just to hold a
    // throwaway error array. For schemas with many disjunctions
    // (e.g. `*true | boolean`, `method: GET | PUT | ...`) this was the
    // single largest source of clones in the unify hot path.
    //
    // Swap-and-restore avoids the clone: the existing ctx's err array
    // is saved, replaced with a fresh array for each trial, then
    // restored. ctx mutation is scoped to this loop and fully undone
    // before return.
    const savedErr = ctx.err
    const savedTrialMode = ctx._trialMode
    // C1-inner: tell `makeNilErr` to return TRIAL_NIL in this scope
    // instead of allocating per-failure NilVals. Save/restore so
    // nested DisjunctVal trials (and the outer non-trial code) are
    // not affected. The restore lives in `finally`: if a trial throws,
    // leaving ctx._trialMode=true would collapse every subsequent real
    // error in this ctx to the shared TRIAL_NIL sentinel.
    ctx._trialMode = true
    try {
      for (let vI = 0; vI < this.peg.length; vI++) {
        const v = this.peg[vI]
        const trialErr: any[] = []
        ctx.err = trialErr

        oval[vI] = unite(te ? ctx.clone({ explain: ec(te, 'DIST:' + vI) }) : ctx, v, peer, 'dj-peer')

        if (0 < trialErr.length) {
          // C1: failed-trial marker is never user-visible — it just
          // signals "this disjunct member doesn't match" and is
          // filtered out before the result is built. Use the shared
          // sentinel instead of allocating a fresh NilVal per trial.
          oval[vI] = TRIAL_NIL
        }

        done = done && DONE === oval[vI].dc
      }
    }
    finally {
      ctx._trialMode = savedTrialMode
      ctx.err = savedErr
    }

    // // // console.log('DISJUNCT-unify-B', this.id, oval.map(v => v.canon))

    // Remove duplicates, and normalize
    if (1 < oval.length) {
      for (let vI = 0; vI < oval.length; vI++) {
        if (oval[vI].isDisjunct) {
          oval.splice(vI, 1, ...oval[vI].peg)
        }
      }

      // // // console.log('DISJUNCT-unify-C', this.id, oval.map(v => v.id + '=' + v.canon))

      // Dedup: duplicate Vals in the disjunct are replaced with the
      // trial sentinel, which is filtered out a few lines below.
      // (No need for a fresh NilVal — any isNil value gets filtered.)
      for (let vI = 0; vI < oval.length; vI++) {
        for (let kI = vI + 1; kI < oval.length; kI++) {
          if (oval[kI].same(oval[vI])) {
            oval[kI] = TRIAL_NIL
          }
        }
      }

      // // // console.log('DISJUNCT-unify-D', this.id, oval.map(v => v.canon))

      oval = oval.filter(v => !v.isNil)
    }

    let out: Val

    if (1 == oval.length) {
      out = oval[0]
    }
    else if (0 == oval.length) {
      return makeNilErr(ctx, '|:empty', this, peer)
    }
    else {
      out = new DisjunctVal({ peg: oval }, ctx)
    }

    out.dc = done ? DONE : this.dc + 1

    // // // console.log('DISJUNCT-unify',
    //   this.id, sc, pc, '->', out.canon, 'D=' + out.dc, 'E=', this.err)

    explainClose(te, out)

    return out
  }


  rankPrefs(ctx: AontuContext) {
    let lastpref: PrefVal | undefined = undefined
    let lastprefI = -1

    // // // console.log('RP-A', this.peg.map((p: Val) => p.canon))

    for (let vI = 0; vI < this.peg.length; vI++) {
      const v = this.peg[vI]
      if (v instanceof PrefVal) {
        if (null != lastpref) {
          if (v.rank === lastpref.rank) {
            const pref = v.unify(lastpref, ctx) as PrefVal
            if (pref.isNil) {
              return pref
            }
            else {
              this.peg[lastprefI] = pref
              lastpref = pref
              this.peg[vI] = null
            }
            // return Nil.make(ctx, '|:prefs', lastpref, v, 'associate')
          }
          else if (v.rank < lastpref.rank) {
            this.peg[lastprefI] = null
            lastpref = v
            lastprefI = vI
          }
          else {
            this.peg[vI] = null
          }
        }
        else {
          lastpref = v
          lastprefI = vI
        }
      }
      else if (v.isDisjunct) {
        let subrank: any = v.rankPrefs(ctx)
        if (subrank instanceof PrefVal) {
          this.peg[vI] = subrank
          lastpref = subrank
          lastprefI = vI
        }
      }
    }

    this.peg = this.peg.filter((p: any) => null != p)
    this.prefsRanked = true

    // // // console.log('RP-Z', this.peg.map((p: Val) => p.canon))

    if (1 === this.peg.length && this.peg[0] instanceof PrefVal) {
      return this.peg[0]
    }
  }



  clone(ctx: AontuContext, spec?: ValSpec): Val {
    let out = (super.clone(ctx, spec) as DisjunctVal)
    return out
  }


  getJunctionSymbol(): string {
    return '|'
  }


  gen(ctx: AontuContext) {
    // TODO: move this to main unify

    // console.log('DJ-GEN', this.peg.map((p: any) => p.canon), ctx.err)

    if (0 < this.peg.length) {

      let vals = this.peg.filter((v: Val) => v instanceof PrefVal)
      // // // console.log('DJ-GEN-VALS-A', vals.map((p: any) => p.canon))

      vals = 0 === vals.length ? this.peg : vals

      let val = vals[0]

      // TODO: over unifies complex types like maps
      // ({x:1}|{y:2})&{z:3} should be {"x":1,"z":3}|{"y":2,"z":3} not { x:1, z:3, y:2 }
      for (let vI = 1; vI < vals.length; vI++) {
        // Index `vals`, not `this.peg`: when the pref members are not the
        // leading entries the two arrays differ, and folding against
        // this.peg[vI] would unify the wrong (or a repeated) member.
        let valnext = val.unify(vals[vI], ctx)
        // // // console.log('DJ-GEN-VALS-NEXT', valnext.canon)
        val = valnext
      }

      // console.log('DJ-GEN-VALS-B', val.canon)
      const out = val.gen(ctx)
      // console.log('DJ-GEN-VALS-C', out)
      return out
    }

    return super.gen(ctx)

    // // // console.log('DJ-GEN', this.peg)

    // if (1 === this.peg.length) {
    //   return this.peg[0].gen(ctx)
    // }
    // else if (1 < this.peg.length) {
    //   let peg = this.peg.filter((v: Val) => v instanceof PrefVal)

    //   if (1 === peg.length) {
    //     return peg[0].gen(ctx)
    //   }
    //   else {

    //     let nil = Nil.make(
    //       ctx,
    //       'disjunct',
    //       this,
    //       undefined
    //     )

    //     // TODO: refactor to use Site
    //     nil.path = this.path
    //     nil.site.url = this.url
    //     nil.site.row = this.row
    //     nil.site.col = this.col

    //     // descErr(nil, ctx)

    //     if (null == ctx) {
    //       throw new Error(nil.msg)
    //     }
    //   }

    //   return undefined
    // }
  }
}




export {
  DisjunctVal,
}
