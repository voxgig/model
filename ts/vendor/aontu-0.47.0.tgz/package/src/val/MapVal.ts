/* Copyright (c) 2021-2025 Richard Rodger, MIT License */


import type {
  Val,
  ValSpec,
} from '../type'

import {
  DONE,
  SPREAD,
} from '../type'

import { AontuContext } from '../ctx'
import { unite } from '../unify'

import {
  propagateMarks,
  walk,
  explainOpen,
  ec,
  explainClose,
} from '../utility'

import { makeNilErr, AontuError } from '../err'

import {
  top
} from './top'


import { ConjunctVal } from './ConjunctVal'
import { NilVal } from './NilVal'
import { BagVal } from './BagVal'


// Per-RefVal structural snapshot of a ref spread (see MapVal.unify). A
// module-level WeakMap keyed by the (per-parse) RefVal: persists across
// fixpoint passes without polluting the RefVal (so clones don't inherit
// it) and is GC'd with the parse.
const SPREAD_SNAP = new WeakMap<Val, Val>()


class MapVal extends BagVal {
  isMap = true

  constructor(
    spec: ValSpec,
    ctx?: AontuContext
  ) {
    super(spec, ctx)

    if (null == this.peg) {
      throw new AontuError('MapVal spec.peg undefined')
    }

    this.mark.type = !!spec.mark?.type
    this.mark.hide = !!spec.mark?.hide

    let spread = (this.peg as any)[SPREAD]
    delete (this.peg as any)[SPREAD]

    if (spread) {
      if ('&' === spread.o) {
        // TODO: handle existing spread!
        this.spread.cj =
          Array.isArray(spread.v) ?
            1 < spread.v.length ?
              new ConjunctVal({ peg: spread.v }, ctx) :
              spread.v[0] :
            spread.v
      }
    }

    // console.log('MAPVAL-ctor', this.type, spec)
  }


  // NOTE: order of keys is not preserved!
  // not possible in any case - consider {a,b} unify {b,a}
  unify(peer: Val, ctx: AontuContext): Val {
    // console.log('MAPVAL-UNIFY', this.id, this.canon, peer.id, peer.canon)

    const TOP = top()
    peer = peer ?? TOP
    const te = ctx.explain && explainOpen(ctx, ctx.explain, 'Map', this, peer)

    let done: boolean = true
    let exit = false

    // NOTE: not a clone! needs to be constructed.
    let out: MapVal | NilVal = (peer.isTop ? this : new MapVal({ peg: {} }, ctx))

    out.closed = this.closed
    out.optionalKeys = [...this.optionalKeys]
    out.spread.cj = this.spread.cj
    out.site = this.site

    if (peer instanceof MapVal) {
      if (!this.closed && peer.closed) {
        out = peer.unify(this, te ? ctx.clone({ explain: ec(te, 'PMC') }) : ctx) as MapVal
        exit = true
      }

      // ensure determinism of unification
      else if (this.closed && peer.closed) {
        const peerkeys = Object.keys(peer.peg)
        const selfkeys = Object.keys(this.peg)

        if (
          peerkeys.length < selfkeys.length
          || (peerkeys.length === selfkeys.length
            && peerkeys.join('~') < selfkeys.join('~')
          )
        ) {
          out = peer.unify(this, te ? ctx.clone({ explain: ec(te, 'SPC') }) : ctx) as MapVal
          exit = true
        }

      }

      if (!exit) {
        out.spread.cj = null == out.spread.cj ? peer.spread.cj : (
          null == peer.spread.cj ? out.spread.cj : (
            // Combine two distinct spread constraints structurally (deferred
            // via a ConjunctVal) rather than unifying in place. A spread is
            // a template applied per destination key; unifying here resolves
            // its key()/path() at the template's own (intermediate) path,
            // producing spurious values. Identical templates (same canon)
            // collapse to one — otherwise the conjunct grows every fixpoint
            // pass since the spread re-combines each pass.
            out.spread.cj = out.spread.cj.canon === peer.spread.cj.canon ?
              out.spread.cj :
              new ConjunctVal({ peg: [out.spread.cj, peer.spread.cj] }, ctx)
          )
        )
      }
    }
    else {
      // console.log('MAPVAL-PEER-OTHER', this.id, this.canon, this.done, peer.id, peer.canon, peer.done)
    }


    if (!exit) {
      out.dc = this.dc + 1

      // let newtype = this.type || peer.type

      let spread_cj = out.spread.cj ?? TOP

      // Snapshot a path-dependent *ref* spread to its structural target
      // once (while inner key()/path() funcs are still unresolved), so
      // later fixpoint passes don't re-resolve the ref against the mutated
      // tree and capture the target's own resolved key()/path() literals,
      // which would leak the source key into the spread destination.
      if (spread_cj.isRef && (spread_cj as any).find) {
        let snap: Val | undefined = SPREAD_SNAP.get(spread_cj)
        if (undefined === snap) {
          let tgt: Val | undefined = (spread_cj as any).find(ctx)
          // A ref to a type() resolves to its inner template (see the
          // unwrap below) — snapshot that, so a type-wrapped ref behaves
          // like a plain-map ref spread (key() captured unresolved, then
          // resolved at the destination).
          if (tgt && (tgt as any).isTypeFunc) tgt = (tgt as any).peg?.[0]
          // Only snapshot a found, path-dependent target (contains
          // key()/path()/ref). If the target is not present yet (it may be
          // introduced by a later conjunct/merge), do NOT cache — retry on
          // the next fixpoint pass (otherwise we'd freeze the unresolved
          // ref and never snapshot the real target).
          if (tgt && tgt.isVal && tgt.isPathDependent) {
            snap = tgt.clone(ctx)
            // Clear TYPE marks on the snapshot (recursively): a type()
            // template constrains values but must not make the spread
            // destination type-invisible at any depth. HIDE marks are
            // preserved — a hide() spread is meant to hide the destination
            // field (see spread-hide).
            walk(snap, (_k: any, v: Val) => {
              v.mark.type = false
              return v
            })
            SPREAD_SNAP.set(spread_cj, snap)
          }
        }
        if (snap) spread_cj = snap
      }

      // A type() used as a spread applies as its inner template: emit the
      // (constrained) values at each destination rather than marking the
      // destination as a type. I.e. `&:type({k:key(),x:number})` behaves
      // like the non-type spread `&:{k:key(),x:number}` — key() resolves
      // to the destination key, kinds constrain, fields are emitted.
      if ((spread_cj as any).isTypeFunc) {
        spread_cj = (spread_cj as any).peg?.[0] ?? TOP
      }

      // Always unify own children first
      for (let key in this.peg) {
        const keyctx = ctx.descend(key)

        const key_spread_cj = spread_cj.spreadClone(keyctx)
        const child = this.peg[key]

        propagateMarks(this, child)

        out.peg[key] =
          undefined === child ? key_spread_cj :
            child.isNil ? child :
              key_spread_cj.isNil ? key_spread_cj :
                key_spread_cj.isTop && child.done ? child :
                  child.isTop && key_spread_cj.done ? key_spread_cj :
                    unite(te ? keyctx.clone({ explain: ec(te, 'KEY:' + key) }) : keyctx,
                      child, key_spread_cj, 'map-own')

        done = (done && DONE === out.peg[key].dc)
      }

      const allowedKeys: string[] = this.closed ? Object.keys(this.peg) : []
      let bad: NilVal | undefined = undefined

      if (peer instanceof MapVal) {
        let upeer: MapVal = peer.done ? peer as MapVal : (unite(
          te ? ctx.clone({ explain: ec(te, 'PER') }) : ctx,
          peer, TOP, 'map-peer-map') as MapVal)

        for (let peerkey in upeer.peg) {
          let peerchild = upeer.peg[peerkey]

          if (this.closed && !allowedKeys.includes(peerkey)) {
            bad = makeNilErr(ctx, 'closed', peerchild, undefined)
          }

          // key optionality is additive
          if (upeer.optionalKeys.includes(peerkey) && !out.optionalKeys.includes(peerkey)) {
            out.optionalKeys.push(peerkey)
          }

          let child = out.peg[peerkey]

          const peerctx = ctx.descend(peerkey)

          let oval = out.peg[peerkey] =
            undefined === child ? this.handleExpectedVal(peerkey, peerchild, this, ctx) :
              child.isTop && peerchild.done ? peerchild :
                child.isNil ? child :
                  peerchild.isNil ? peerchild :
                    unite(te ? peerctx.clone({ explain: ec(te, 'CHD') }) : peerctx,
                      child, peerchild, 'map-peer')

          if (this.spread.cj) {
            let key_spread_cj = spread_cj.spreadClone(peerctx)

            oval = out.peg[peerkey] =
              unite(te ? peerctx.clone({ explain: ec(te, 'PSP:' + peerkey) }) : peerctx,
                oval, key_spread_cj, 'map-peer-spread')
          }

          propagateMarks(this, oval)

          done = (done && DONE === oval.dc)
        }
      }
      else if (!peer.isTop) {
        out = makeNilErr(ctx, 'map', this, peer)
      }

      if (null != bad) {
        out = bad
      }

      if (!out.isNil) {
        ;(out.uh ??= []).push(peer.id)

        out.dc = done ? DONE : out.dc
        propagateMarks(peer, out)
        propagateMarks(this, out)
      }
    }

    // console.log(
    //   'MAPVAL-OUT', out.canon,
    //   '\n  SELF', this,
    //   '\n  PEER', peer,
    //   '\n  OUT', out,
    //   '\n  FROM', (out as any).spread.cj
    // )

    ctx.explain && explainClose(te, out)

    return out
  }


  // Spread clone: return a Val usable as the per-key spread constraint.
  //
  // Three tiers:
  //   1. tree is path-independent (no RefVal/KeyFuncVal/PathFuncVal/
  //      MoveFuncVal/SuperFuncVal anywhere below): return `this` directly.
  //      Nothing in the unify path mutates the spread root, and no
  //      child depends on its own stored .path, so sharing is safe.
  //   2. top-level children are all ScalarKindVal: shallow clone
  //      (share children, fresh MapVal wrapper).
  //   3. otherwise: full deep clone via `this.clone(ctx)`.
  //
  // Tier 1 handles the foo-sdk common case of simple type-constraint
  // spreads like `&:{active: *true | boolean, version: *'0.0.1' | string}`,
  // which are cloned thousands of times per run.
  spreadClone(ctx: AontuContext): Val {
    if (!this.isPathDependent) return this

    let allScalarKind = true
    for (let key in this.peg) {
      if (!(this.peg[key] as any)?.isScalarKind) {
        allScalarKind = false
        break
      }
    }

    if (!allScalarKind) {
      return this.clone(ctx)
    }

    let out = (super.clone(ctx) as MapVal)
    out.peg = {}

    for (let entry of Object.entries(this.peg)) {
      out.peg[entry[0]] = entry[1]
    }

    // Must create a new spread object to avoid mutating the original.
    out.spread = {
      cj: this.spread.cj ? this.spread.cj.spreadClone(ctx) : undefined,
    }

    out.closed = this.closed
    out.optionalKeys = [...this.optionalKeys]

    return out
  }


  clone(ctx: AontuContext, spec?: ValSpec): Val {
    let out = (super.clone(ctx, spec) as MapVal)
    out.peg = {}

    for (let entry of Object.entries(this.peg)) {
      out.peg[entry[0]] =
        (entry[1] as any)?.isVal ?
          // (entry[1] as Val).clone(ctx, spec?.mark ? { mark: spec.mark } : {}) :
          (entry[1] as Val).clone(ctx, {
            mark: spec?.mark ?? {},
            path: [...out.path, entry[0]]
          }) :
          entry[1]
    }
    if (this.spread.cj) {
      out.spread.cj = this.spread.cj.clone(ctx, spec?.mark ? { mark: spec.mark } : {})
    }

    out.closed = this.closed
    out.optionalKeys = [...this.optionalKeys]

    // out.from = this.from

    // console.log('MAPVAL-CLONE', this.canon, '->', out.canon)
    return out
  }


  get canon() {
    let keys = Object.keys(this.peg)
    return '' +
      // this.errcanon() +
      // (this.mark.type ? '<type>' : '') +
      // (this.id + '=') +
      '{' +
      (this.spread.cj ? '&:' + this.spread.cj.canon +
        (0 < keys.length ? ',' : '') : '') +
      keys
        .map(k => [
          JSON.stringify(k) +
          (this.optionalKeys.includes(k) ? '?' : '') +
          ':' +
          (this.peg[k]?.canon ?? this.peg[k])
        ])
        .join(',') +
      '}' // + '<' + (this.mark.hide ? 'H' : '') + '>'

  }


  inspection(d?: number) {
    return this.spread.cj ? '&:' + this.spread.cj.inspect(null == d ? 0 : d + 1) : ''
  }

}


export {
  MapVal
}
